import 'package:flutter/material.dart';

class Vista1 extends StatelessWidget {
  const Vista1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('La guaracha sabrosona'),
      ),
    );
  }
}
