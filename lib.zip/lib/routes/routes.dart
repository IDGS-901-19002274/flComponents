import 'package:fl_components/Views/nuevavista1.dart';
import 'package:flutter/cupertino.dart';

import '../Views/alert.dart';
import '../Views/avatar.dart';
import '../Views/home.dart';

Map<String, WidgetBuilder> getAplicationRoutes() {
  return <String, WidgetBuilder>{
    '/': (BuildContext context) => const Home(),
    'alert': (BuildContext context) => const AlertPage(),
    'avatar': (BuildContext context) => const AvatarPage(),
    'nuevavista1': (BuildContext context) => const Vista1()
  };
}
